[t, P] = poblacion(1, 0, 100);
plot(t,P);