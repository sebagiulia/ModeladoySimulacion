[t, P] = poblacion2(1,0,100);
plot(t,P);
    