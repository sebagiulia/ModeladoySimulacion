p(t) = p(t+1)
p(t) = p(t) + b*p(t) - d*p(t)*p(t)
p(t) = p(t)(1 + b - d*p(t))

1 = 1 + b - d*p(t) |
p(t) = b/d         |-> si p(t) != 0
p(t) = 10          |

p(t) = 0